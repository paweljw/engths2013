#!/bin/bash

cd ~/engths2013/soft/build
rm -r *
cmake -G "Unix Makefiles" ..
